#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include <iostream>

//===----------------------------------------------------------------------===//
// Lexer
//===----------------------------------------------------------------------===//

// The lexer returns tokens [0-255] if it is an unknown character, otherwise one
// of these for known things.

// ToDo: Implement the lexer by finishing the function 'gettok()', it will process 
// the input stream and return an enum Token.

enum Token {
  tok_eof = -1,  // the end of the file

  // commands
  tok_def = -2,  // the 'func' key word; every function in this lab is begin with them 
  tok_var = -3,  // the 'var' key word;
  tok_const = -4,  // the 'const' key word;
  tok_type = -5,   // 'int' or 'double';

  // primary
  tok_identifier = -6,  // [A-Z_a-z][0-9A-Z_a-z]*
  tok_number_int = -7,  // [0-9][0-9]* 
  tok_number_double = -8,  // <intconst>.<intconst>
};

enum Types {
  type_int = 1,
  type_double = 2
};



static FILE *fip;
static std::string IdentifierStr; // Filled in if tok_identifier
static int NumValI;             // Filled in if tok_number_int
static double NumValD;             // Filled in if tok_number_double
static int ValType;              // Filled in with type kind


static std::map<std::string, int> TypeValues;  // map typeString to int; You can choose to use this
static void InitializeTypeValue(){
  TypeValues["int"] = 1;
  TypeValues["double"] = 2;
}

/// gettok - Return the next token from standard input.
static int gettok() {
  static int LastChar = ' ';
  std::map<std::string, int>::iterator iter;

  // Skip any whitespace.
  while (isspace(LastChar))
    LastChar = fgetc(fip);

  
  if (isalpha(LastChar)) { 
  //------------------------------------------
  // TODO: identifier // def // var // const // type
  //------------------------------------------- 
  }

  
  if (isdigit(LastChar)){
  //-----------------------------------
  // TODO: number_int // number_double
  //-----------------------------------
  }

  // Check for end of file.
  if (LastChar == EOF)
    return tok_eof;

  // Otherwise, just return the character as its ascii value.
  int ThisChar = LastChar;
  LastChar = fgetc(fip);
  return ThisChar;
}

//===----------------------------------------------------------------------===//
// Abstract Syntax Tree (aka Parse Tree)
//===----------------------------------------------------------------------===//

//                            Future Work

//===----------------------------------------------------------------------===//
// Parser
//===----------------------------------------------------------------------===//
/// CurTok/getNextToken - Provide a simple token buffer.  CurTok is the current
/// token the parser is looking at.  getNextToken reads another token from the
/// lexer and updates CurTok with its results.
static int CurTok;
static int getNextToken() { return CurTok = gettok(); }

//                            Future Work

//===----------------------------------------------------------------------===//
// Code Generation
//===----------------------------------------------------------------------===//

//                            Future Work

//===----------------------------------------------------------------------===//
// Top-Level
//===----------------------------------------------------------------------===//

//                            Future Work

//===----------------------------------------------------------------------===//
// Main driver code.
//===----------------------------------------------------------------------===//

int main(int argc, char* argv[]) {
  //file check
  if(argc < 2){
    std::cout << "You need to specify the file to compile" << std::endl;
    return 1;
  }
  char* FileName = argv[1];
  fip = fopen(FileName, "r");
  if(fip == nullptr){
    std::cout << "The file '" << FileName << "' is not existed" << std::endl;
    return 1;
  }

  InitializeTypeValue();

  //output
  while (true) {
    getNextToken();
    switch (CurTok){
      case tok_def:
        std::cout << "tok_def" << std::endl;
        break;
      case tok_number_double:
        std::cout << "tok_number_double" << " " << NumValD << std::endl;
        break;
      case tok_number_int:
        std::cout << "tok_number_int" << " " << NumValI << std::endl;
        break;
      case tok_const:
        std::cout << "tok_const" << " " << NumValI << std::endl;
        break;
      case tok_var:
        std::cout << "tok_var" << " " << NumValI << std::endl;
        break;
      case tok_type:
      {
        std::string val_type = "double";
        if(ValType == 1)
          val_type = "int";
        std::cout << "tok_type" << " " << val_type << std::endl;
        break;
      }
      case tok_identifier:
        std::cout << "tok_identifier" << " " << IdentifierStr << std::endl;
        break;
      default:
        if(CurTok > 0)
          std::cout << (char)CurTok << std::endl;
        else
          std::cout << CurTok << std::endl;
        break;
    }
    if(CurTok == -1){
      break;
    }
  }
  return 0;
}