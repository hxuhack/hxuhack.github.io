#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include <iostream>

//===----------------------------------------------------------------------===//
// Lexer
//===----------------------------------------------------------------------===//

// The lexer returns tokens [0-255] if it is an unknown character, otherwise one
// of these for known things.
enum Token {
  tok_eof = -1,  // the end of the file

  // commands
  tok_def = -2,  // the 'func' key word; every function in this lab is begin with them 
  tok_var = -3,  // the 'var' key word;
  tok_const = -4,  // the 'const' key word;
  tok_type = -5,   // 'int' or 'double';

  // primary
  tok_identifier = -6,  // [A-Z_a-z][0-9A-Z_a-z]*
  tok_number_int = -7,  // [0-9][0-9]* 
  tok_number_double = -8,  // <intconst>.<intconst>
};

enum Types {
  type_int = 1,
  type_double = 2
};


static std::map<std::string, int> TypeValues;  //map typeString to int
static FILE *fip;
static std::string IdentifierStr; // Filled in if tok_identifier
static int NumValI;             // Filled in if tok_number_int
static double NumValD;             // Filled in if tok_number_double
static int ValType;

static void InitializeTypeValue(){
  TypeValues["int"] = 1;
  TypeValues["double"] = 2;
}

/// gettok - Return the next token from standard input.
static int gettok() {
///***********************************************
///use gettok implemented in lexer
///***********************************************
}


//===----------------------------------------------------------------------===//
// Abstract Syntax Tree (aka Parse Tree)
//===----------------------------------------------------------------------===//
// you don't have to modify this part. (of course it is ok to add something if needed)
namespace {

/// ExprAST - Base class for all expression nodes. <exp> in Grammar
class ExprAST {
public:
  virtual ~ExprAST() = default;

  virtual void output() { return; }
};

/// NumberDoubleExprAST - Expression class for double literals. <doubleconst> in Grammar
class NumberDoubleExprAST : public ExprAST {
  double Val;

public:
  NumberDoubleExprAST(double Val) : Val(Val) {}
  void output() override{
    std::cout << "(DoubleVal: " << Val << ")";
  }
};

/// NumberIntExprAST - Expression class for int literals. <intconst> in Grammar
class NumberIntExprAST : public ExprAST {
  int Val;

public:
  NumberIntExprAST(int Val) : Val(Val) {}
  void output() override{
    std::cout << "(IntVal: " << Val << ")";
  }
};

/// VariableExprAST - Expression class for referencing a variable. <ident> in Grammar
class VariableExprAST : public ExprAST {
  std::string Name;

public:
  VariableExprAST(const std::string &Name) : Name(Name) {}
  void output() override{
    std::cout << "(Variable: " << Name << ")";
  }
};

/// BinaryExprAST - Expression class for a binary operator. <expr> <binop> <expr>
class BinaryExprAST : public ExprAST {
  char Op;
  std::unique_ptr<ExprAST> LHS, RHS;

public:
  BinaryExprAST(char Op, std::unique_ptr<ExprAST> LHS,
                std::unique_ptr<ExprAST> RHS)
      : Op(Op), LHS(std::move(LHS)), RHS(std::move(RHS)) {}
  void output() override{
    std::cout << "(";
    LHS->output();
    std::cout << Op;
    RHS->output();
    std::cout << ")";
  }
};

/// CallExprAST - Expression class for function calls. <callee> in Grammar
class CallExprAST : public ExprAST {
  std::string Callee;
  std::vector<std::unique_ptr<ExprAST>> Args;

public:
  CallExprAST(const std::string &Callee,
              std::vector<std::unique_ptr<ExprAST>> Args)
      : Callee(Callee), Args(std::move(Args)) {}

  void output() override{
    std::cout << "(Call: " << Callee << " (Args: ";
    for(auto &Arg : Args){
      Arg->output();
    }
    std::cout << "))";
  }
};

/// PrototypeAST - This class represents the "prototype" for a function,
/// <prototype> in Grammar
class PrototypeAST {
  std::string Name;
  std::vector<std::string> Args;
  std::vector<int> ArgTypes;
  int FnType;

public:
  PrototypeAST(const std::string &Name, std::vector<std::string> Args, std::vector<int> ArgTypes, int FnType)
      : Name(Name), Args(std::move(Args)), ArgTypes(std::move(ArgTypes)), FnType(FnType) {}

  const std::string &getName() const { return Name; }
  const int getReturnType() {return FnType;}
  const std::vector<int> &getArgTypes() {return ArgTypes;}

  void output(){
    std::cout << "(Function: " << Name << std::endl << "(Args:";
    for(auto &Arg : Args){
      std::cout << " " << Arg;
    }
    std::cout << ")" << std::endl << "(ArgTypes:";
    for(auto ArgType : ArgTypes){
      std::cout << " " << ArgType;
    }
    std::cout << ")" << std::endl << "(FnType: " << FnType << "))" << std::endl;
  }
};

/// FunctionAST - This class represents a function definition itself.
/// <function> in Grammar
class FunctionAST {
  std::unique_ptr<PrototypeAST> Proto;
  std::unique_ptr<ExprAST> Body;

public:
  FunctionAST(std::unique_ptr<PrototypeAST> Proto,
              std::unique_ptr<ExprAST> Body)
      : Proto(std::move(Proto)), Body(std::move(Body)) {}

  void output(){
    Proto->output();
    Body->output();
    std::cout << std::endl;
  }
};
} 

//===----------------------------------------------------------------------===//
// Parser
//===----------------------------------------------------------------------===//

/// CurTok/getNextToken - Provide a simple token buffer.  CurTok is the current
/// token the parser is looking at.  getNextToken reads another token from the
/// lexer and updates CurTok with its results.
static int CurTok;
static int getNextToken() { return CurTok = gettok(); }
/// BinopPrecedence - This holds the precedence for each binary operator that is
/// defined.
static std::map<char, int> BinopPrecedence;

/// LogError* - These are little helper functions for error handling.
/// you can add additional function to help you log error. 
std::unique_ptr<ExprAST> LogError(const char *Str) {
  fprintf(stderr, "Error: %s\n", Str);
  return nullptr;
}

std::unique_ptr<PrototypeAST> LogErrorP(const char *Str) {
  LogError(Str);
  return nullptr;
}

std::unique_ptr<FunctionAST> LogErrorF(const char *Str) {
  LogError(Str);
  return nullptr;
}


/*TODO: Finish the Parse*() function to implement the Parser.
  We provide some implemented Parse* function for reference, like 
  ParseNumberExpr(), which are marked with "example", and you can use these functions directly. 
  >>>note: You can add some other Parse*() function to help you achieve this goal,
  >>>e.g. ParseParenExpr() which parenexpr ::= '(' expression ')'.
*/




/// numberexpr ::= number
/// example
static std::unique_ptr<ExprAST> ParseNumberExpr(int NumberType) {
  if (NumberType == type_double){
    auto Result = std::make_unique<NumberDoubleExprAST>(NumValD);
    getNextToken(); // consume the number
    return std::move(Result);
  }
  else{
    auto Result = std::make_unique<NumberIntExprAST>(NumValI);
    getNextToken(); // consume the number
    return std::move(Result);
  }
}


/// identifierexpr
/// <ident> or <callee>
/// TODO
static std::unique_ptr<ExprAST> ParseIdentifierExpr() {
  return nullptr;
}


/// expression
/// <exp>
/// TODO
static std::unique_ptr<ExprAST> ParseExpression() {
  return nullptr;
}

/// statement 
/// <stmt>
/// example
static std::unique_ptr<ExprAST> ParseStatement() {
  auto E = ParseExpression();
  return E;
}

/// prototype
/// <prototype>
/// an imcomplete parse function. It can parse <prototype> without args.
/// TODO
static std::unique_ptr<PrototypeAST> ParsePrototype() {
  getNextToken(); // eat func.
  if (CurTok != tok_identifier)
    return LogErrorP("Expected function name in prototype");
  
  std::string FnName = IdentifierStr;
  getNextToken(); // eat FnName
  if (CurTok != '(')
    return LogErrorP("Expected '(' in prototype");
  getNextToken(); // eat '('.
  std::vector<std::string> ArgNames;
  std::vector<int> ArgTypes;
  if (CurTok != ')')
    return LogErrorP("Expected ')' in prototype");
  getNextToken(); // eat ')'.
  if (CurTok != tok_type)
    return LogErrorP("Need to declare the return type");
  int FnType = ValType;
  getNextToken(); // eat return type.
  // success.
  return std::make_unique<PrototypeAST>(FnName, std::move(ArgNames), std::move(ArgTypes), FnType);
}

/// definition ::= 'def' prototype expression
/// <function>
/// TODO
static std::unique_ptr<FunctionAST> ParseDefinition() {
  return nullptr;
}


//===----------------------------------------------------------------------===//
// Code Generation
//===----------------------------------------------------------------------===//

//                        Future Work

//===----------------------------------------------------------------------===//
// Top-Level
//===----------------------------------------------------------------------===//
//don't modify this part

static void HandleDefinition() {
  if (auto FnAST = ParseDefinition()) {
    std::cout << "Parsed a function definition" << std::endl;
    FnAST->output();
  } else {
    // Skip token for error recovery.
    getNextToken();
  }
}



/// top: definition 
static void MainLoop() {
  while (true) {
    switch (CurTok) {
    case tok_eof:
      return;
    case tok_def:
      HandleDefinition();
      break;
    default:
      std::cout << "invalid input" << std::endl;
      getNextToken();
      break;
    }
  }
}
//===----------------------------------------------------------------------===//
// Main driver code.
//===----------------------------------------------------------------------===//
//don't modify this part

int main(int argc, char* argv[]) {
  
  if(argc < 2){
    std::cout << "You need to specify the file to compile" << std::endl;
    return 1;
  }
  char* FileName = argv[1];
  fip = fopen(FileName, "r");
  if(fip == nullptr){
    std::cout << "The file '" << FileName << "' is not existed" << std::endl;
    return 1;
  }
  InitializeTypeValue();

  BinopPrecedence['<'] = 10;
  BinopPrecedence['+'] = 20;
  BinopPrecedence['-'] = 20;
  BinopPrecedence['*'] = 40; // highest.

  getNextToken();


  MainLoop();

  return 0;
}