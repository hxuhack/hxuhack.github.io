#include <iostream>

extern "C" {
	    int foo(int, int);
}

int main() {
	    std::cout << "test of foo(3, 8) is :" << foo(3, 8) << std::endl;
	    std::cout << "test of foo(11, 9) is :" << foo(11, 9) << std::endl;
}
